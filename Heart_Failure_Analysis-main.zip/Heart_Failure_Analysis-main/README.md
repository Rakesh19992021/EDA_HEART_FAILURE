# Heart_Failure_Analysis
 The following project helps us to explore the relations between the various biological factors and the heary failure.
